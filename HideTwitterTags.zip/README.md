# HideTwitterTags

Hide Twitter Tags Trends and elements (All languages)

# Features

 <ul>
    🌠 Hide:
 
 ⭐ Trends and Tags.<br>
 ⭐ Topics to follow.<br>
 ⭐ Who to follow.<br>
 ⭐ Relevant people.<br>
 ⭐ Footer.<br>
 ⭐ Search (Shown by default)<br>
 ⭐ Explore Button (Shown by default) 
</ul>

![Screenshot](https://github.com/Sal7one/HideTwitterTags/blob/master/newscreenshot.png?raw=true)

# How to use

Download from here!

Chrome:
[DOWNLOAD (Chrome Web Store)](https://chrome.google.com/webstore/detail/twitter-tags-hider/njfgdkckokikphjhheihclmnjnbchfci)

FireFox:
[DOWNLOAD (Mozila Addons)](https://addons.mozilla.org/en-US/firefox/addon/twitter-tags-and-trends-hider/)

[FireFox Repository](https://github.com/Sal7one/HideTwitterTags/tree/firefoxversion)

You can also
Download as Zip file, Open chrome Extensions and load the folder as unpacked
